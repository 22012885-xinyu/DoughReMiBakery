/**
 * 
 * I declare that this code was written by me, txy81. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: tay xin yu
 * Student ID: 22012885
 * Class: C372-4D-E63C-A
 * Date created: 2023-Nov-16 9:47:43 pm 
 * 
 */

package e63c.tayxinyu.ga;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author txy81
 *
 */
public interface CategoryRepository extends JpaRepository<Category, Integer> {

}
