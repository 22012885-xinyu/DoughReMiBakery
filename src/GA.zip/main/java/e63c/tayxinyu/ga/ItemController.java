/**
 * 
 * I declare that this code was written by me, txy81. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: tay xin yu
 * Student ID: 22012885
 * Class: C372-4D-E63C-A
 * Date created: 2023-Nov-16 9:40:07 pm 
 * 
 */

package e63c.tayxinyu.ga;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author txy81
 *
 */
@Controller
public class ItemController {
	@Autowired
	private ItemRepository itemRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@GetMapping("/items")
	public String viewItems(Model model) {
		
		List<Item> listItems = itemRepository.findAll();
		
		model.addAttribute("listItems", listItems);
		return "view_items";
	}
	@GetMapping("/items/add")
	public String addItem(Model model) {
		model.addAttribute("item", new Item());
		return "add_item";
	}
 
	@PostMapping("/items/save")
	public String saveItem(Item item) {
		itemRepository.save(item);
		return "redirect:/items";
	}
 
	@GetMapping("/items/edit/{id}")
	public String editItem(@PathVariable("id") Integer id, Model model) {
		Item item  = itemRepository.getReferenceById(id);
		model.addAttribute("item", item);
		return "edit_item";
	}
	@PostMapping("/items/edit/{id}")
	public String saveUpdatedItem(@PathVariable("id") Integer id, Item item) {
		itemRepository.save(item);
		return "redirect:/items";
	}
	@GetMapping("/items/delete/{id}")
	public String deleteItem(@PathVariable("id") Integer id) {
		itemRepository.deleteById(id);
		return "redirect:/";
	}
}
