/**
 * 
 * I declare that this code was written by me, txy81. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: tay xin yu
 * Student ID: 22012885
 * Class: C372-4D-E63C-A
 * Date created: 2023-Nov-16 9:45:50 pm 
 * 
 */

package e63c.tayxinyu.ga;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import e63c.tayxinyu.ga.Category;
import e63c.tayxinyu.ga.CategoryRepository;

/**
 * @author txy81
 *
 */
@Controller
public class CategoryController {
	@Autowired
	private CategoryRepository categoryRepository;
 
	@GetMapping("/categories")
	public String viewCategories(Model model) {
 
		List<Category> listCategories = categoryRepository.findAll();
 
		model.addAttribute("listCategories", listCategories);
		return "view_categories";
	}
 
	@GetMapping("/categories/add")
	public String addCategory(Model model) {
		model.addAttribute("category", new Category());
		return "add_category";
	}
 
	@PostMapping("/categories/save")
	public String saveCategory(Category category) {
		categoryRepository.save(category);
		return "redirect:/categories";
	}
 
	@GetMapping("/categories/edit/{id}")
	public String editCategory(@PathVariable("id") Integer id, Model model) {
		Category category = categoryRepository.getReferenceById(id);
		model.addAttribute("category", category);
		return "edit_category";
	}
	@PostMapping("/categories/edit/{id}")
	public String saveUpdatedCategory(@PathVariable("id") Integer id, Category category) {
		categoryRepository.save(category);
		return "redirect:/categories";
	}
	@GetMapping("/categories/delete/{id}")
	public String deleteCategory(@PathVariable("id") Integer id) {
		categoryRepository.deleteById(id);
		return "redirect:/categories";
	}
}
