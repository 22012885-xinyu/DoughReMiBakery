package e63c.tayxinyu.ga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GaApplication.class, args);
	}

}
