SELECT * FROM ga.item;
INSERT INTO item (id,description,name,price,quantity,img_name) VALUES (1,'Rich chocolate cake with fresh cherries upon every bite.','Blackforest Cake',10,2,'bf.jpeg');
INSERT INTO item (id,description,name,price,quantity,img_name) VALUES (2,'Fresh fruits layered in dense spongecake.','Fruit Cake',5.5,3,'fruit.jpg');
INSERT INTO item (id,description,name,price,quantity,img_name) VALUES (3,'Lychee flavoured cake with a hint of rose.','Lychee Rose Cake',0.8,1,'lr.jpeg');
INSERT INTO item (id,description,name,price,quantity,img_name) VALUES (4,'Layers of spongecake with cream cheese in between.','Rainbow Cake',4.5,1,'rb.png');
INSERT INTO item (id,description,name,price,quantity,img_name) VALUES (5,'Vanilla and chocolate cake with cream cheese.','Red Velvet Cake',4.5,1,'rv.png');